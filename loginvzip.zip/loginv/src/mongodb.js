const mongoose = require("mongoose");
const OrganizationSchema=require('./orgschema');
const FoodDetailsSchema = require('./foodschema');

const app=require('./index');
console.log(typeof app); // Check the type of the app object


mongoose.connect("mongodb://localhost:27017/Login")
    .then(() => {
        console.log("MongoDB connected successfully");
    })
    .catch((error) => {
        console.error("Failed to connect to MongoDB:", error);
    });

const loginSchema = new mongoose.Schema({
    Name: {
        type: String,
        required: true
    },
    Password: {
        type: String,
        required: true
    },
    Email: {
        type: String,
        required: true
    },
    location: {
        type: String,
        required: true
    }
});

const collection = mongoose.model("Collection1", loginSchema);

module.exports = collection;

// Define schema for the food details
/*const FoodDetailsSchema = new mongoose.Schema({
    foodType: { type: String, required: true },
    amount: { type: Number, required: true },
    foodName: { type: String, required: true },
    pickupTime: { type: Date, required: true },
    manufacturingDate: { type: Date, required: true },
    expiryDate: { type: Date, required: true }
});


// Define model for the food details
const FoodDetails = mongoose.model('FoodDetails', FoodDetailsSchema);

module.exports = FoodDetails;
*/
// const Organization = mongoose.model("Organization", OrganizationSchema);

// Route for the organization registration page
// app.get("/organization", (req, res) => {
//     res.render("organization");
// });

// // Route to handle organization registration
// app.post("/register-organization", async (req, res) => {
//     try {
//         // Retrieve organization data from the request body
//         const { name, password, email, location, photoProof } = req.body;

//         // Create a new organization instance
//         const newOrganization = new Organization({
//             name,
//             password,
//             email,
//             location,
//             photoProof
//         });

//         // Save the organization data to the database
//         await newOrganization.save();

//         // Respond with a success message
//         res.status(201).send('Organization registered successfully');
//     } catch (error) {
//         // Handle errors
//         console.error(error);
//         res.status(500).send('Internal Server Error');
//     }
// });

// app.listen(3000, () => {
//     console.log("Server is running on port 3000");
// });