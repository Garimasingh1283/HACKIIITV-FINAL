const mongoose=require('mongoose');

const FoodDetailsSchema = new mongoose.Schema({
    foodType: { type: String, required: true },
    amount: { type: Number, required: true },
    foodName: { type: String, required: true },
    pickupTime: { type: Date, required: true },
    manufacturingDate: { type: Date, required: true },
    expiryDate: { type: Date, required: true }
});

// Define model for the food details
const FoodDetails = mongoose.model('FoodDetails', FoodDetailsSchema);
module.exports = FoodDetails;

