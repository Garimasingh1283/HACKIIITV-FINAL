const express = require ("express")
const app= express()
const path=require("path")
const hbs= require("hbs")
const cors=require("cors")

app.use(cors())
const templatePath= path.join(__dirname,'../templates')
const collection = require("./mongodb")
const Organization=require('./orgschema');
const FoodDetails=require('./foodschema')
const bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json())
app.set("view engine", "hbs")
app.set("views",templatePath)
app.use(express.urlencoded({extended:false}))

app.get("/",(req,res)=>{
    res.render("login")
})
app.post('/signup', async (req, res) => {
    try {
        console.log("yo bro")
        // Retrieve user data from the request body
        const { Name, Password, Email,location } = req.body;

        // Create a new user instance
        const newUser = new collection({
            Name,
            Password,
            Email,
            location
        });

        // Save the user data to the database
        await newUser.save();
        console.log("here")
        // Respond with a success message
        res.status(201).send('User registered successfully');
    } catch (error) {
        // Handle errors
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

app.post("/Login",async(req,res)=>{
    console.log(req.body);
const data={
    Name: req.body.Name,
    // Email:req.body.Email,
    // Location:req.body.Location,
    Password: req.body.Password
}

await collection.insertMany([data])
res.render("home")

})


// Route for the food details page
app.get("/food-details", (req, res) => {
    res.render("food-details");
});

app.get("/organization", (req, res) => {
    res.render("organization");
});

// Route to handle organization registration
app.post("/register-organization", async (req, res) => {
    try {
        // Retrieve organization data from the request body
        const { name, password, email, location, photoProof } = req.body;

        // Create a new organization instance
        const newOrganization = new Organization({
            name,
            password,
            email,
            location,
            photoProof
        });

        // Save the organization data to the database
        await newOrganization.save();

        // Respond with a success message
        res.status(201).send('Organization registered successfully');
    } catch (error) {
        // Handle errors
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});


app.post("/submit-food-details", async (req, res) => {
    try {
        // Retrieve food pickup details from the request body
        const { foodType, amount, foodName, pickupTime, manufacturingDate, expiryDate } = req.body;

        // Create a new document for the food pickup details
        const newFoodDetails = new FoodDetails({
            foodType,
            amount,
            foodName,
            pickupTime,
            manufacturingDate,
            expiryDate
        });

        // Save the food pickup details to the database
        await newFoodDetails.save();

        // Respond with a success message
        res.status(201).send('Food pickup details submitted successfully');
    } catch (error) {
        // Handle errors
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});


// org name , photo proof, location,email,pw .. pg2: no of people, type of food, quanity , deli time



module.exports = app;
app.listen(3000,()=>{
    console.log("port connected");
});
